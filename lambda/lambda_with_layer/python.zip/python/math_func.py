def sum(x, y):
    return x+y

def square(n):
    return n**2